﻿using CodeFirst.Models;
using CodeFirst.Models.ModeBinding;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace CodeFirst.Controllers
{
    public class HomeController : Controller
    {
        private readonly MyContext dbcontext;

        public HomeController(MyContext _dbcontex)
        {
            dbcontext = _dbcontex;
        }

        

        public IActionResult Index()
        {
            GRstudent grs = new GRstudent()
            {
                student = dbcontext.Students.ToList(),
                group = dbcontext.Groups.ToList()
            };




            return View(grs);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
