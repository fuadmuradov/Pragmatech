﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CodeFirst.Models
{
    public class MyContext : DbContext
    {
        public MyContext(DbContextOptions<MyContext> options) : base(options) {
        
          
        }
        public DbSet<Group> Groups { get; set; }
        public DbSet<Student> Students { get; set; }

       protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Group>().HasData(
                new Group {id = 1, Gname="PM", number=221},
                new Group { id= 2, Gname = "FM", number =223 },
                new Group { id=3, Gname = "RM", number = 225 }
                );
        }
    }
}
