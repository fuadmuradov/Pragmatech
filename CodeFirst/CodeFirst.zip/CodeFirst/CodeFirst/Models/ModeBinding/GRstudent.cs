﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CodeFirst.Models.ModeBinding
{
    public class GRstudent
    {
        public IList<Student>  student { get; set; }
        public IList<Group> group { get; set; }
    }
}
