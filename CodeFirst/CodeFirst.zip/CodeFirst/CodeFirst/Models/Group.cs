﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CodeFirst.Models
{
    public class Group
    {   [Key]
        public int id { get; set; }
        public string Gname { get; set; }
        public int number { get; set; }
    }
}
