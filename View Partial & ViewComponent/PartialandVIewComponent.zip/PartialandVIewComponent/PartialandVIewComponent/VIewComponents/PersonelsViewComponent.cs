﻿using Microsoft.AspNetCore.Mvc;
using PartialandVIewComponent.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PartialandVIewComponent.VIewComponents
{
    public class PersonelsViewComponent:ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            List<Personel> personel = new List<Personel>()
            {
                new Personel{id = 1, Name = "Fuad", Lastname="Muradov"},
                new Personel{id = 2, Name = "Murad", Lastname = "Muradov"},
                new Personel{id = 3, Name = "Nihad", Lastname = "Muradov"},
                new Personel{id = 4, Name = "Orxan", Lastname="Qarayev"}
            };
            return View(personel);
        }
    }
}
