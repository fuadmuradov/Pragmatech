﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManager.Models
{
    public class MyContext : DbContext
    {
        public MyContext(DbContextOptions<MyContext> options) : base(options) { }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Department>().HasData(
                new Department { id = 1, Name = "HR" },
                new Department { id = 2, Name = "R&D" },
                new Department { id = 3, Name = "Production" },
                new Department { id = 4, Name = "Purchasing" },
                new Department { id = 5, Name = "Marketing" }
                );
        }

    }
}
