﻿using EmployeeManager.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManager.Controllers
{
    public class HomeController : Controller
    {
        private readonly MyContext dbcontext;

        public HomeController(MyContext myContext) => dbcontext = myContext;

        public IActionResult Index()
        {
        

            return View(dbcontext.Employees.ToList());
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Edit(int? id)
        {
            if (id==null)
            {
                return RedirectToAction(nameof(Index));
            }

          Employee emp = dbcontext.Employees.Find(id);
            if (emp==null)
            {
                return RedirectToAction(nameof(Index));
            }

            TempData["id"] = id;
            
            return View(emp);
        }

        public IActionResult Addemp()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Edit(int id, string Name, string Lastname, int Depid)
        {
            Employee employee = new Employee
            {
                id = id,
                Name = Name,
                Lastname = Lastname,
                DepId = Depid
            };

            var emp = dbcontext.Employees.FirstOrDefault(x => x.id == id);
            emp.Name = Name;
            dbcontext.SaveChanges();
            return RedirectToAction(nameof(Index));
        }



        [HttpPost]
        public IActionResult Addemp(string Name, string Lastname, int Depid)
        {
            Employee emp = new Employee
            {
                Name = Name,
                Lastname = Lastname,
                DepId = Depid
            };
            dbcontext.Employees.Add(emp);
            dbcontext.SaveChanges();

            return RedirectToAction(nameof(Index));
        }

        public IActionResult Delete(int? id)
        {
            Employee emp = dbcontext.Employees.Find(id);
            if (emp == null)
            {
                return NotFound();
            }

            dbcontext.Employees.Remove(emp);
            dbcontext.SaveChanges();


            return RedirectToAction(nameof(Index));
        }



    }
}
