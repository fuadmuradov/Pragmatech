﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GetDataUser.Models.ViewModel
{
    public class ProductUser
    {
        List<Product> products;
        List<User> users;
    }
}
