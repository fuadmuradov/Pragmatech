﻿using GetDataUser.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GetDataUser.Controllers
{
    public class myclass
    {
        public int id { get; set; }
        public string name { get; set; }
    }

    public class AjaxData
    {
        public string A { get; set; }
        public string Betta { get; set; }
    }

    public class ProductController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        //public IActionResult CreateProduct()
        //{
            /* product obyektini CreateProduct view-a gonderilir
             *  uygun inputlarin deyerleri 
             *  Proyekt Run olduqda inputlarin deyeril olaraq gorunur
             */
            //Product product = new Product
            //{
            //    ProductName = "BMW",
            //    Quantity = 12
            //};
            // return View(product);
        //    return View();
        //}
        // [HttpPost]
        //public IActionResult CreateProduct(string txtProductName, string txtQuantity)
        //{
        //    return View();
        //}
        //Model Binding
        //public IActionResult CreateProduct(Product product)
        //{
        //    return View();
        //}

        //IFormControl get Data from User
        //public IActionResult CarProduct(IFormCollection datas)
        //{
        //    var value1 = datas["txtValue1"];
        //    var value2 = datas["txtValue2"];
        //    var value3 = datas["txtValue3"];

        //    return View();
        //}


        //QueryString get Data from URL example:https://localhost:44342/Product/carproduct?a=12&b=20 a=12, b=20
        //public IActionResult CarProduct(string a, string b)
        //{

        //    return View();
        //}



        //get data with Route parametre
        //public IActionResult CarProduct(string id, string name)
        //{
        //    return View();
        //}
        //public IActionResult CarProduct(myclass cc)
        //{
        //     var value = Request.RouteValues; 
        //    return View();
        //}

        public IActionResult CreateProduct()
        {
            var tuple = (new Product(), new User());
            return View(tuple);
        }

        //[HttpPost]
        //public IActionResult CreateProduct([Bind(Prefix ="Item1")] Product product, [Bind(Prefix ="Item2")] User user)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        var tuple = (product, user);
        //        return View(tuple);
        //    }


           
        //    return View();
        //}


        public IActionResult GetData(AjaxData data)
        {
            return View(CreateProduct());
        }

    }
}
