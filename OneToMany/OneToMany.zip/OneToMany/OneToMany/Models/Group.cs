﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OneToMany.Models
{
    public class Group
    {
        public int id { get; set; }
        public string Name { get; set; }
        public int Number { get; set; }
        public List<Student> StudentList { get; set; }

    }
}
