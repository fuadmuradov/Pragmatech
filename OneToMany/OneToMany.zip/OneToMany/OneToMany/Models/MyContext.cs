﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
 

namespace OneToMany.Models
{
    public class MyContext:DbContext
    {
        public MyContext(DbContextOptions<MyContext> options) : base(options) { }
        public DbSet<Group> Groups { get; set; }
        public DbSet<Student> Students { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Group>().HasData(
                new Group {id=1, Name="PR", Number=343},
                new Group { id = 2, Name ="LR", Number=445},
                new Group { id = 3, Name ="KR", Number=556},
                new Group { id = 4, Name ="QR", Number=766}
                );
        }

    }
}
