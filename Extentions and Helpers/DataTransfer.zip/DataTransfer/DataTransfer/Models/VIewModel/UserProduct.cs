﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DataTransfer.Models.VIewModel
{
    public class UserProduct
    {
        public User userr { get; set; }
        public Product productt { get; set; }
    }
}
