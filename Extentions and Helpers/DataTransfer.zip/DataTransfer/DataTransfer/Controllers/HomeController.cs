﻿using DataTransfer.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace DataTransfer.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
         //  var x = TempData["x"];
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Vproduct()
        {
            ViewBag.Message = "Ha Ha Haaaaaaaaaa";

            var product = new List<Product>
            {
                new Product{Id = 1, Name="Maybach", Model="Mercedes"},
                new Product{Id = 2, Name="M5 Compressor", Model="BMW"},
                new Product{Id = 3, Name="GTR" , Model = "Nissan"}
            };

            #region ViewModel

            Product product1 = new Product
            {
                Id = 1,
                Name = "M5 Compressor",
                Model = "BMW"
            };

            User user = new User
            {
                Id = 1,
                Name = "Fuad",
                Surname = "Muradov"

            };

            //Models.VIewModel.UserProduct uspro = new Models.VIewModel.UserProduct
            //{
            //    userr = user,
            //    productt = product1
            //};

            //return View(uspro);

            //Using Tuple Send Data
          //  var userproduct = (product1, user);

           // return View(userproduct);
            #endregion

            #region Model base send Data
            //return View(product);
            #endregion

            #region ViewBag send Data

            //ViewBag.product = product;

            #endregion

            #region ViewData
            //ViewData["product"] = product;
            #endregion

            #region TempData

            //TempData["product"] = product;

            //TempData["x"] = 5;

            //RedirectToAction("Index"); // Sendin Data To Index View(Index Action)
            #endregion



            return View();

        }

        public IActionResult ListPartial2()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
