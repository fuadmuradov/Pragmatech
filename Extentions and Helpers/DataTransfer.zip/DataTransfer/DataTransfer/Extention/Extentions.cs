﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DataTransfer.Extention
{
    public static class Extentions
    {
        //public static IHtmlContent CustomTextBox(this IHtmlHelper htmlHelper, string name, string value, string placeHolder)
        //=>
        //    htmlHelper.TextBox(name, value, new
        //    {
        //        style = "background-color:yellow; color:black",
        //        a = "a",
        //        bbb = "b",
        //        placeholder = placeHolder
        //    });

        public static IHtmlContent CustomTextBox(this IHtmlHelper htmlHelper, string name, string value, string placeHolder = "")
            =>
                htmlHelper.TextBox(name, value, new
                {
                style = "background-color:yellow; color:black; Width:400px; Height:100px",
                    aa = "Aa",
                    b="b",
                    placeholder = placeHolder
                });
    }

}
