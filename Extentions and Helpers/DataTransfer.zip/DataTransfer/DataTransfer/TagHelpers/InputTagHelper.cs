﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DataTransfer.TagHelpers
{
 //   [HtmlTargetElement("chooseEmail")]; tag-adini deyismek olar
    public class InputTagHelper : TagHelper
    {
        public string Type { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
       
        public string Placeholder { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "input";
            output.Attributes.Add("type", Type);
            output.Attributes.Add("name", Name);
            output.Attributes.Add("value", Value);
            output.Attributes.Add("style", "background-color:yellow; color:black; width:300px");
            output.Attributes.Add("placeholder", Placeholder);
            
        }

    }
}
