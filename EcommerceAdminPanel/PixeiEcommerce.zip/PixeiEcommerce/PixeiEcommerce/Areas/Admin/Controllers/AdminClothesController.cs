﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PixeiEcommerce.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PixeiEcommerce.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class AdminClothesController : Controller
    {
        private readonly MyContext dbcontext;
        public AdminClothesController(MyContext _dbContext)
        {
            dbcontext = _dbContext;
        }

        public IActionResult Index()
        {
            return View(dbcontext.Goods.ToList());
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(string nname, int price, int quantity)
        {
            Good good = new Good
            {
                name = nname,
                price = price,
                quantity = quantity
            };

            dbcontext.Goods.Add(good);
            dbcontext.SaveChanges();

            return Redirect("Index");
            return View();
        }

        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            return View();
        }


        public IActionResult Delete(int id)
        {
            if (id == null)
            {
                return NotFound();
            }

            return View();
        }

    }
}
