﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPnetCoreMVC.Models
{
    public static class Images
    {
        public static List<ImageItem> image = new List<ImageItem>
            {
               new ImageItem{id = 1, BookName = "A Swim in a Pond in the Rain", Writer = "by George Saunders", link = "10.jfif"},
               new ImageItem{id = 2, BookName = "Writing Better Lyrics", Writer="by Pat Pattison" , link = "11.jfif"},
               new ImageItem{id = 3, BookName = "Living with a Dead Language",Writer="by Ann Patty", link = "12.jfif"},
               new ImageItem{id = 4, BookName = "Bird by Bird",Writer="by Anne Lamott", link = "13.jfif"},
               new ImageItem{id = 5, BookName = "The Clothing of Books", Writer="by Jhumpa Lahiri", link = "14.jfif"},
               new ImageItem{id = 6, BookName = "Negotiating with the Dead", Writer="by Margaret Atwood", link = "15.jfif"}
            };

        public static List<ImageItem> getImage() => image;

    }

    public class ImageItem
    {
        public int id { get; set; }
        public string BookName { get; set; }
        public string Writer { get; set; }
        public string link { get; set; }
    }
}
