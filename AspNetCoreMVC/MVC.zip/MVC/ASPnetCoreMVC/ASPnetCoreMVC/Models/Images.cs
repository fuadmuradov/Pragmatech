﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPnetCoreMVC.Models
{
    public static class Images
    {
        public static List<ImageItem> image = new List<ImageItem>
            {
               new ImageItem{id = 1, titleName = "photo_1", link = "1.jpg"},
               new ImageItem{id = 2, titleName = "photo_2", link = "2.jpeg"},
               new ImageItem{id = 3, titleName = "photo_3", link = "3.jpg"},
               new ImageItem{id = 4, titleName = "photo_4", link = "3.jpg"},
               new ImageItem{id = 5, titleName = "photo_5", link = "1.jpg"},
               new ImageItem{id = 6, titleName = "photo_6", link = "2.jpeg"}
            };

        public static List<ImageItem> getImage() => image;

    }

    public class ImageItem
    {
        public int id { get; set; }
        public string titleName { get; set; }
        public string link { get; set; }
    }
}
