﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Vesperr.Models
{
    public class MoreServiceSection
    {
        public int id { get; set; }
        public string photo { get; set; }
        public string title { get; set; }
        public string description { get; set; }
    }
}
