﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Vesperr.Models
{
    public class Team
    {
        public int id { get; set; }
        public string photo { get; set; }
        public string fullname { get; set; }
        public string jobname { get; set; }

    }
}
