﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Vesperr.Models
{
    public class AboutCount
    {
        public int id { get; set; }
        public string icon { get; set; }
        public int count { get; set; }
        public string Strongtitle { get; set; }
        public string title { get; set; }
    }
}
