﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Vesperr.Models
{
    public class Portfolio
    {
        public int id { get; set; }
        public string photo { get; set; }
        public string name { get; set; }
        public string category { get; set; }

    }
}
