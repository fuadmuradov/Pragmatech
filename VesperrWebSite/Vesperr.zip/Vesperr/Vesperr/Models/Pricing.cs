﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Vesperr.Models
{
    public class Pricing
    {
        public int id { get; set; }
        public string type { get; set; }
        public int price { get; set; }
        public string time { get; set; }
        public string title1 { get; set; }
        public string title2 { get; set; }
        public string title3 { get; set; }
        public string title4 { get; set; }
        public string title5 { get; set; }

    }
}
