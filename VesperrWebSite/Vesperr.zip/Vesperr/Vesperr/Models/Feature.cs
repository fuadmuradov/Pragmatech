﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Vesperr.Models
{
    public class Feature
    {
        public int id { get; set; }
        public string icon { get; set; }
        public string title { get; set; }


    }
}
